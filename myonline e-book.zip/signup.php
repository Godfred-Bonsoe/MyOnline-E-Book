<?php 
    session_start();

    include("connection.php");
    include("functions.php");

    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        //something was posted
        $user_name = $_POST['user_name'];
        $password = $_POST['password'];
        $firstname =$_POST['firstname'];
        $lastname = $_POST['lastname'];
        $date_of_birth = $_POST['date_of_birth'];
        $gender = $_POST['gender'];
        $phone = $_POST['phone'];

        if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
        {
            //save to database
            $user_id = random_num(10);
            $query = "insert into new_users (user_id,user_name,password,firstname,lastname,date_of_birth,gender,phone) values ('$user_id','$user_name','$password','$firstname','$lastname','$date_of_birth','$gender','$phone')";

            mysqli_query($con, $query);

            header("Location: login.php");
            die;
        }else
        {
           echo"Please enter some valid information";
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
  <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" media="screen" href="./css/style.css" />
      <link href="./css/css/all.css" rel="stylesheet">
      <!-- Bootstrap CSS -->

      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

    <title>Online Library | Sign Up</title>
    <style>body{background:url('./images/carousel10.jpg');}input{width:100%;border:none;border-bottom: 1px solid #007bff;outline: none;padding-bottom: 5px;background-color: #f8f9fa;}select{width:100%;border:none;border-bottom: 1px solid #007bff;outline: none;padding-bottom: 5px;background-color: #f8f9fa;}label{margin-bottom: 6px;display:block;color: #007bff;}date{width:100%;border:none;border-bottom: 1px solid #007bff;outline: none;padding-bottom: 5px;background-color: #f8f9fa;}</style>
</head>
<body>
  <div class="darkback">
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="index.php"><img class="logo" src="./images/mainlogo1.png"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Catalog
              </a>
              <div class="dropdown-menu bg-secondary" aria-labelledby="navbarDropdown">
                <a class="dropdown-item text-white" href="catalog.php">Books</a>
                <a class="dropdown-item text-white" href="ebooks.php">E-Books</a>
                <a class="dropdown-item text-white" href="materials.php">Study Materials</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item text-white" href="request.php">Request</a>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="contact.php">Contact</a>
            </li>
            <li class="nav-item  active">
                <a class="nav-link " href="login.php">Login<span class="sr-only">(current)</span></a>
              </li>
          </ul>
          <a href="index.php"><img class="logo userimage" src="./images/avatar.jpg"></a>
	        <a href="login.php" class="display-5 my-auto ml-2 iden"  >Login</a>
        </div>
      </div>
      </nav>
</header>
<div id="logbox" class="container">
  <div class="container-fluid">
    <div class="row no-gutter mb-4">
      <div class="col-md-5 py-5 px-5 text-light bg-image" >
  <!-- Empty-->
      </div>


        
        <div class="col-md-7 bg-light py-5 px-5">
            <h3 class="display-5 mb-4">Sign Up</h3>
            <form method="POST" id="myForm" autocomplete="off">
              <div class="input-row">
                <div class="input-group">
                  <label>Name</label>
                  <input type="text" name="firstname" class=" rounded-pill border-1 shadow-sm px-4"  placeholder="First name" style="text-transform:capitalize;" required>
                </div>
                <div class="input-group">
                  <label style="color: #f8f9fa;">Lastname</label>
                  <input type="text" name="lastname" class=" rounded-pill border-1 shadow-sm px-4" placeholder="Last name" style="text-transform:capitalize;" required>
                </div>

              </div>
              <div class="input-row">
                <div class="input-group">
                <label for="date_of_birth">Date of Birth:</label>
                <input type="text" id="date-of-birth" name="date_of_birth"  class=" rounded-pill border-1 shadow-sm px-4" placeholder="dd/mm/yyyy" required>
              </div>
              
              <div class="input-group">
                <label>Gender:</label>
                <select class=" rounded-pill border-1 shadow-sm px-4" name="gender" form="myForm">
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>  
              </div>
              </div>
              <div class="input-row">
                <div class="input-group">
                  <label>Email</label>
                  <input type="email" name="user_name" class=" rounded-pill border-1 shadow-sm px-4" placeholder="name@example.com" class="form-control validate">
                </div>
                <div class="input-group">
                  <label>Phone</label>
                  <input type="text" name="phone" class=" rounded-pill border-1 shadow-sm px-4" placeholder="Phone: +233 505 337 676" required>
                </div>

              </div>
              <div class="input-row">
                <div class="input-group">
                  <label>Password</label>
                  <input type="password" name="password" id="password" class=" rounded-pill border-1 shadow-sm px-4" placeholder="Password" class="form-control validate">
                  
                </div>
                <div class="input-group">
                  <label style="color: #f8f9fa;">Confirm password</label>
                  <input type="password" name="password2" id="password2" class=" rounded-pill border-1 shadow-sm px-4" placeholder="Confirm password" class="form-control validate">
                  
                </div>

              </div>
              <label style="color:red;" id="wrong"></label>
              <button type="submit"  onclick="return check()" class="btn btn-primary btn-block text-uppercase mb-2 shadow-sm" style="width:120px;">Submit</button>
              <div class="text-center d-flex justify-content-between mt-4"><p>Already got an acount? <a href="login.php" class="font-italic text-muted">
                                        <u>Log-In</u></a></p></div>
            </form>
            </div>
        </div>

    </div>
</div>
</div>
</div>
<script>
   function ShowPassword(){
 var pass = document.getElementById("psw");
 if (pass.type=="password"){pass.type = "text";}
 else{pass.type = "password";}
}

function ShowCPassword(){
 var Cpass = document.getElementById("Cpsw");
 if (Cpass.type=="password"){Cpass.type = "text";}
 else{Cpass.type = "password";}
}

function check(){
var password = document.getElementById("password").value;
var password2 = document.getElementById("password2").value;
if(password==password2){document.getElementById("wrong").innerHTML = "Form is submitted"; return true;}
else{document.getElementById("wrong").innerHTML = "Password did not match"; return false;}
}
</script>
<footer class="fixed-bottom">
<div class="bg-primary">
        <div class="container">
            <div class="row py4 d-flex align-items-center">
                <div class="col-md-12 text-center py-3">
                    <a href="#"><i class="fab fa-facebook-f text-white mr-4"></i></a>
                    <a href="#"><i class="fab fa-twitter text-white mr-4"></i></a>
                    <a href="#"><i class="fab fa-google-plus-g text-white mr-4"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in text-white mr-4"></i></a>
                    <a href="#"><i class="fab fa-instagram text-white"></i></a>
                </div>
            </div>
        </div>
    </div>
<div class="footer-copyright text-center py-2 bg-secondary">
        <p class="mb-0">&copy;Copyright
            <a class="text-dark" href="#">onlibrary.com</a>
        </p>
    </div>
</footer>
</body>
</html>
