<?php 
    session_start();

    include("connection.php");
    include("functions.php");

    if($_SERVER['REQUEST_METHOD'] == "POST")
    {
        //something was posted
        $user_name = $_POST['user_name'];
        $password = $_POST['password'];
       

        if(!empty($user_name) && !empty($password) && !is_numeric($user_name))
        {
            //read from database
            
            $query = "select * from new_users where user_name = '$user_name' limit 1";

            $result = mysqli_query($con, $query);

            if($result)
            {
                if($result && mysqli_num_rows($result) > 0)
                {
                    $user_data = mysqli_fetch_assoc($result);
                    if($user_data['password'] === $password)
                    {   
                        $_SESSION['user_id'] = $user_data['user_id'];
                        header("Location: index.php");
                        die;
                    }
                } 
            }
            ?>

            <script>
              alert("Wrong username or password");
            </script>
            <?php
        }else
        {
          ?>
            <script>
              alert("Wrong username or password");
            </script>
            <?php
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
  <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" media="screen" href="./css/style.css" />
      <link href="./css/css/all.css" rel="stylesheet">
      <!-- Bootstrap CSS -->

      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

    <title>Online Library | Login/Register</title>
    <style>
      body{
	      background: url(./images/slider-main/bg6.jpg);
      }
    </style>
</head>
<body>
  <div class="darkback">
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
          <a class="navbar-brand" href="index.php"><img class="logo" src="./images/mainlogo1.png"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">About</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Catalog
              </a>
              <div class="dropdown-menu bg-secondary" aria-labelledby="navbarDropdown">
                <a class="dropdown-item text-white" href="catalog.php">Books</a>
                <a class="dropdown-item text-white" href="ebooks.php">E-Books</a>
                <a class="dropdown-item text-white" href="materials.php">Study Materials</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item text-white" href="request.php">Request</a>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="contact.php">Contact</a>
            </li>
            <li class="nav-item  active">
                <a class="nav-link " href="login.php">Login<span class="sr-only">(current)</span></a>
              </li>
        </ul>
          <a href="index.php"><img class="logo userimage" src="./images/icon-image/avatar2.jpg" style="border-radius:50%;"></a>
          <a href="./admin/adminlogin.php" class="display-5 my-auto ml-2 iden"  >Login as Admin</a>
         
        
        </div>
      </div>
      </nav>
</header>

<div id="logbox" class="container">
  <div class="container-fluid">
    <div class="row no-gutter">
        <!-- The image half -->
        <div class="col-md-6 d-none d-md-flex bg-image">
			<!-- image goes here -->
		</div>


        <!-- The content half -->
        <div class="col-md-6 bg-light">
            <div class="login d-flex align-items-center py-5">

                <!-- content-->
                <div class="container">
                    <div class="row">
                        <div class="col-lg-10 col-xl-7 mx-auto">
                            <h3 class="display-4">Log In</h3>
                            <p class="text-muted mb-4">Sign in to access our wide range collection of books.</p>
                            <form method="POST" autocomplete="off">
                                <div class="form-group mb-3">
                                    <input id="inputEmail" type="email" placeholder="E-mail" required="" autofocus="" class="form-control rounded-pill border-0 shadow-sm px-4" name="user_name">
                                </div>
                                <div class="form-group mb-3">
                                    <input id="inputPassword" type="password" placeholder="Password" required="" class="form-control rounded-pill border-0 shadow-sm px-4 text-primary" name="password">
                                </div>
                                <div class="custom-control custom-checkbox mb-3">
                                    <input id="customCheck1" type="checkbox" checked class="custom-control-input">
                                    <label for="customCheck1" class="custom-control-label">Remember password</label>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block text-uppercase mb-2 rounded-pill shadow-sm">Sign in</button>
                                      
                            </form>
                        </div>
                    </div>
                </div><!-- End -->

            </div>
        </div><!-- End -->

    </div>
</div>
</div>
</div>
<footer class="fixed-bottom">
<div class="bg-primary">
        <div class="container">
            <div class="row py4 d-flex align-items-center">
                <div class="col-md-12 text-center py-3">
                    <a href="#"><i class="fab fa-facebook-f text-white mr-4"></i></a>
                    <a href="#"><i class="fab fa-twitter text-white mr-4"></i></a>
                    <a href="#"><i class="fab fa-google-plus-g text-white mr-4"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in text-white mr-4"></i></a>
                    <a href="#"><i class="fab fa-instagram text-white"></i></a>
                </div>
            </div>
        </div>
    </div>
<div class="footer-copyright text-center py-2 bg-secondary">
        <p class="mb-0">&copy;Copyright
            <a class="text-dark" href="#">onlibrary.com</a>
        </p>
    </div>
</footer>
</body>
</html>

